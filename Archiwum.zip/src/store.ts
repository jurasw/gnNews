import { createStore } from 'redux';

// Define the initial state of the store
interface AppState {
  isButtonOn: boolean;
  number: number;
}

const initialState: AppState = {
  isButtonOn: false,
  number: 0,
};

// Define the actions that can modify the state
enum ActionType {
  TOGGLE_BUTTON = 'TOGGLE_BUTTON',
  INCREMENT_NUMBER = 'INCREMENT_NUMBER',
}

interface ToggleButtonAction {
  type: ActionType.TOGGLE_BUTTON;
}

interface IncrementNumberAction {
  type: ActionType.INCREMENT_NUMBER;
  payload: number;
}

type Action = ToggleButtonAction | IncrementNumberAction;

// Define the reducer function that will handle the actions
function appReducer(state = initialState, action: Action): AppState {
  switch (action.type) {
    case ActionType.TOGGLE_BUTTON:
      return {
        ...state,
        isButtonOn: !state.isButtonOn,
      };
    case ActionType.INCREMENT_NUMBER:
      return {
        ...state,
        number: action.payload,
      };
    default:
      return state;
  }
}

// Create the Redux store with the reducer function
export const store = createStore(appReducer);



// Dispatch actions to modify the state
store.dispatch({ type: ActionType.TOGGLE_BUTTON });
store.dispatch({ type: ActionType.INCREMENT_NUMBER, payload: 5 });

