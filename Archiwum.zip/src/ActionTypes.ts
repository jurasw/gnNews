
export enum ActionType {
    TOGGLE_BUTTON = 'TOGGLE_BUTTON',
    INCREMENT_NUMBER = 'INCREMENT_NUMBER',
  }
  