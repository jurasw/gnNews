import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { ActionType } from "../../ActionTypes";
import { store } from "../../store";
import ContentGrid from "./ContentGrid";
import ContentList from "./ContentList";

const NewsContent: React.FC = () => {
  const { id } = useParams();
  const state = store.getState();
  const [data, setData] = useState([
    {
      source: {
        id: "",
        name: "",
      },
      author: "",
      title: "",
      description: "",
      url: "",
      urlToImage: "",
      publishedAt: "",
      content: "",
    },
  ]);
  //${process.env.REACT_APP_API_KEY}
  useEffect(() => {
    axios
      .get(
        `top-headlines?country=${id}&apiKey=cd1920a34a96406180b01ba1dd62b4d9`
      )
      .then(function (response) {
        setData(response.data.articles);
        store.dispatch({
          type: ActionType.INCREMENT_NUMBER,
          payload: response.data.articles.length,
        });
      })
      .catch(function (error) {
        console.log(error);
      });
  }, [id]);

  return (
    <>
      <p>{`test: ${state.isButtonOn}`}</p>

      {state.isButtonOn ? (
        <ContentGrid data={data} />
      ) : (
        <ContentList data={data} />
      )}
    </>
  );
};

export default NewsContent;
