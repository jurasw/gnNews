export const HeaderModal = () => {
  return (
    <div>
      <p>Biggest difficulty: Managing news display state in sub-component</p>
      <p>The greatest fun: designing the website</p>
    </div>
  );
};
