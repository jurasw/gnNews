import { Footer } from "antd/es/layout/layout";
import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import { store } from "../store";

const PageFooter: React.FC = () => {
  const state = store.getState();

  const [currentTime, setCurrentTime] = useState(
    new Date().toLocaleTimeString()
  );

  const updateTime = () => {
    setCurrentTime(new Date().toLocaleTimeString());
  };

  setInterval(updateTime, 1000);

  return (
    <Footer style={{ textAlign: "center" }}>
      {currentTime} | {state.number} | © Jerzy Wiśniewski 2023
    </Footer>
  );
};

export default PageFooter;
