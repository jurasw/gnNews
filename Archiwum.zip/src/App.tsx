import React from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import CountryNews from "./pages/CountryNews";
import LandingPage from "./pages/LandingPage";

const App: React.FC = () => {
  return (
    <>
    <BrowserRouter>
      <Routes>
        <Route>
          <Route index element={<LandingPage />} />
          <Route path='/country/:id' element={<CountryNews />} />
        </Route>
      </Routes>
    </BrowserRouter>
    </>
  );
};

export default App;
